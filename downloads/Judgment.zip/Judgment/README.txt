     ____.         .___                             __   
    |    |__ __  __| _/ ____   _____   ____   _____/  |_ 
    |    |  |  \/ __ | / ___\ /     \_/ __ \ /    \   __\
/\__|    |  |  / /_/ |/ /_/  >  Y Y  \  ___/|   |  \  |  
\________|____/\____ |\___  /|__|_|  /\___  >___|  /__|  
                    \/_____/       \/     \/     \/      


By: Christian Dinh 2014


Objective: Prevent asteroids (my friend Kyle's head) from hitting the Earth

Controls: [Z] to shoot, [Arrow Keys] to move

System requirements: a toaster with JVM installed
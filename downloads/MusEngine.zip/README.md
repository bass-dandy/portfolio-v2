```                                                                           
    _/      _/                      _/                  _/_/_/                     
   _/_/  _/_/  _/    _/    _/_/_/        _/_/_/      _/          _/_/    _/_/_/    
  _/  _/  _/  _/    _/  _/_/      _/  _/            _/  _/_/  _/_/_/_/  _/    _/   
 _/      _/  _/    _/      _/_/  _/  _/            _/    _/  _/        _/    _/    
_/      _/    _/_/_/  _/_/_/    _/    _/_/_/        _/_/_/    _/_/_/  _/    _/     
```                                                                                                                                                            

Author: Christian Dinh

Procedural music generator written in Java.
Uses the JFugue API (by David Koelle) to create (hopefully) pleasant songs through application of music theory.
